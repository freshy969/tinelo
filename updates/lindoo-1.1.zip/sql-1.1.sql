DROP TABLE IF EXISTS `gifts`;
CREATE TABLE `gifts` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `gift` varchar(50) NOT NULL,
  `price` int(5) NOT NULL DEFAULT '0',
  `icon` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;



INSERT INTO `gifts` VALUES ('1', 'Treasure', '500', '1.png');
INSERT INTO `gifts` VALUES ('2', 'Cake', '100', '2.png');
INSERT INTO `gifts` VALUES ('3', 'Wine', '100', '3.png');
INSERT INTO `gifts` VALUES ('4', 'Flowers ', '250', '4.png');
INSERT INTO `gifts` VALUES ('5', 'Present', '200', '5.png');
INSERT INTO `gifts` VALUES ('6', 'Heart candy', '150', '6.png');
INSERT INTO `gifts` VALUES ('7', 'kiss', '100', '7.png');
INSERT INTO `gifts` VALUES ('8', 'beer', '100', '8.png');
INSERT INTO `gifts` VALUES ('10', 'cup', '250', '10.png');
INSERT INTO `gifts` VALUES ('11', 'flower', '100', '11.png');
INSERT INTO `gifts` VALUES ('12', 'crown', '1500', '12.png');
INSERT INTO `gifts` VALUES ('13', 'hearts', '250', '13.png');
INSERT INTO `gifts` VALUES ('14', 'hear candy 2', '200', '14.png');
INSERT INTO `gifts` VALUES ('15', 'champagne', '500', '15.png');
INSERT INTO `gifts` VALUES ('16', 'coffe', '150', '16.png');
INSERT INTO `gifts` VALUES ('17', 'cupido', '250', '17.png');
INSERT INTO `gifts` VALUES ('18', 'flowers 3', '500', '18.png');
INSERT INTO `gifts` VALUES ('19', 'dairy love', '100', '19.png');
INSERT INTO `gifts` VALUES ('20', 'handcops', '500', '20.png');
INSERT INTO `gifts` VALUES ('21', 'heart', '100', '21.png');
INSERT INTO `gifts` VALUES ('22', 'heart 2', '250', '22.png');
INSERT INTO `gifts` VALUES ('23', 'heart 3', '150', '23.png');
INSERT INTO `gifts` VALUES ('24', 'ring', '1000', '24.png');
INSERT INTO `gifts` VALUES ('25', 'bear', '250', '26.png');

ALTER TABLE `config` ADD `fAI` VARCHAR( 255 );
ALTER TABLE `config` ADD `fapi` VARCHAR( 255 );
ALTER TABLE `config` ADD `fcountry` VARCHAR( 255 );
UPDATE `config` SET `fcountry` ='United states';
UPDATE `config` SET `fapi` ='No';
UPDATE `config` SET `fAI` ='Yes';